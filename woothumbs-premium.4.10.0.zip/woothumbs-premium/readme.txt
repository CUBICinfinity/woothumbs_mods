=== WooThumbs - Awesome Product Imagery ===
Contributors: iconicwp
Requires at least: 4.7.4
Tested up to: 5.8
Stable tag: trunk